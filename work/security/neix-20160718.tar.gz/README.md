
Code for Livecoding and Algorithmic AV Drones.

( SuperCollider + Puredata )

SuperCollider 3.6.3 : http://supercollider.github.io/

Pd-L2Ork version 20160614 : http://l2ork.music.vt.edu/main/make-your-own-l2ork/software/

Devilspie2 : http://www.gusnan.se/devilspie2/

Linux Mint : https://www.linuxmint.com/

You can see, listen and download the works on: http://musicnumbers.es/

