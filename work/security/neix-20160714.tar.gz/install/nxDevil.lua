
debug_print(get_application_name());

if (get_application_name()=="Untitled - SuperCollider IDE") then
	set_opacity(0.5);
	maximize();
end









